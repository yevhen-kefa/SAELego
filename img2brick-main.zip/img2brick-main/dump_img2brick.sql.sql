-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 21 déc. 2025 à 11:56
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `img2brick_2`
--

-- --------------------------------------------------------

--
-- Structure de la table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `line1` varchar(255) NOT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `mosaic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `colors`
--

CREATE TABLE `colors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `hex_code` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `colors`
--

INSERT INTO `colors` (`id`, `name`, `hex_code`) VALUES
(-1, '[Unknown]', '0033B2'),
(0, 'Black', '05131D'),
(1, 'Blue', '0055BF'),
(2, 'Green', '237841'),
(3, 'Dark Turquoise', '008F9B'),
(4, 'Red', 'C91A09'),
(5, 'Dark Pink', 'C870A0'),
(6, 'Brown', '583927'),
(7, 'Light Gray', '9BA19D'),
(8, 'Dark Gray', '6D6E5C'),
(9, 'Light Blue', 'B4D2E3'),
(10, 'Bright Green', '4B9F4A'),
(11, 'Light Turquoise', '55A5AF'),
(12, 'Salmon', 'F2705E'),
(13, 'Pink', 'FC97AC'),
(14, 'Yellow', 'F2CD37'),
(15, 'White', 'FFFFFF'),
(17, 'Light Green', 'C2DAB8'),
(18, 'Light Yellow', 'FBE696'),
(19, 'Tan', 'E4CD9E'),
(20, 'Light Violet', 'C9CAE2'),
(21, 'Glow In Dark Opaque', 'D4D5C9'),
(22, 'Purple', '81007B'),
(23, 'Dark Blue-Violet', '2032B0'),
(25, 'Orange', 'FE8A18'),
(26, 'Magenta', '923978'),
(27, 'Lime', 'BBE90B'),
(28, 'Dark Tan', '958A73'),
(29, 'Bright Pink', 'E4ADC8'),
(30, 'Medium Lavender', 'AC78BA'),
(31, 'Lavender', 'E1D5ED'),
(32, 'Trans-Black IR Lens', '635F52'),
(33, 'Trans-Dark Blue', '0020A0'),
(34, 'Trans-Green', '84B68D'),
(35, 'Trans-Bright Green', 'D9E4A7'),
(36, 'Trans-Red', 'C91A09'),
(40, 'Trans-Brown', '635F52'),
(41, 'Trans-Light Blue', 'AEEFEC'),
(42, 'Trans-Neon Green', 'F8F184'),
(43, 'Trans-Very Lt Blue', 'C1DFF0'),
(45, 'Trans-Dark Pink', 'DF6695'),
(46, 'Trans-Yellow', 'F5CD2F'),
(47, 'Trans-Clear', 'FCFCFC'),
(52, 'Trans-Purple', 'A5A5CB'),
(54, 'Trans-Neon Yellow', 'DAB000'),
(57, 'Trans-Neon Orange', 'FF800D'),
(60, 'Chrome Antique Brass', '645A4C'),
(61, 'Chrome Blue', '6C96BF'),
(62, 'Chrome Green', '3CB371'),
(63, 'Chrome Pink', 'AA4D8E'),
(64, 'Chrome Black', '1B2A34'),
(68, 'Very Light Orange', 'F3CF9B'),
(69, 'Light Purple', 'CD6298'),
(70, 'Reddish Brown', '582A12'),
(71, 'Light Bluish Gray', 'A0A5A9'),
(72, 'Dark Bluish Gray', '6C6E68'),
(73, 'Medium Blue', '5A93DB'),
(74, 'Medium Green', '73DCA1'),
(75, 'Speckle Black-Copper', '05131D'),
(76, 'Speckle DBGray-Silver', '6C6E68'),
(77, 'Light Pink', 'FECCCF'),
(78, 'Light Nougat', 'F6D7B3'),
(79, 'Milky White', 'FFFFFF'),
(80, 'Metallic Silver', 'A5A9B4'),
(81, 'Metallic Green', '899B5F'),
(82, 'Metallic Gold', 'DBAC34'),
(84, 'Medium Nougat', 'AA7D55'),
(85, 'Dark Purple', '3F3691'),
(86, 'Light Brown', '7C503A'),
(89, 'Royal Blue', '4C61DB'),
(92, 'Nougat', 'D09168'),
(100, 'Light Salmon', 'FEBABD'),
(110, 'Violet', '4354A3'),
(112, 'Medium Bluish Violet', '6874CA'),
(114, 'Glitter Trans-Dark Pink', 'DF6695'),
(115, 'Medium Lime', 'C7D23C'),
(117, 'Glitter Trans-Clear', 'FFFFFF'),
(118, 'Aqua', 'B3D7D1'),
(120, 'Light Lime', 'D9E4A7'),
(125, 'Light Orange', 'F9BA61'),
(129, 'Glitter Trans-Purple', 'A5A5CB'),
(132, 'Speckle Black-Silver', '05131D'),
(133, 'Speckle Black-Gold', '05131D'),
(134, 'Copper', 'AE7A59'),
(135, 'Pearl Light Gray', '9CA3A8'),
(137, 'Pearl Sand Blue', '7988A1'),
(142, 'Pearl Light Gold', 'DCBC81'),
(143, 'Trans-Medium Blue', 'CFE2F7'),
(148, 'Pearl Dark Gray', '575857'),
(150, 'Pearl Very Light Gray', 'ABADAC'),
(151, 'Very Light Bluish Gray', 'E6E3E0'),
(158, 'Yellowish Green', 'DFEEA5'),
(178, 'Flat Dark Gold', 'B48455'),
(179, 'Flat Silver', '898788'),
(182, 'Trans-Orange', 'F08F1C'),
(183, 'Pearl White', 'F2F3F2'),
(191, 'Bright Light Orange', 'F8BB3D'),
(212, 'Bright Light Blue', '9FC3E9'),
(216, 'Rust', 'B31004'),
(226, 'Bright Light Yellow', 'FFF03A'),
(230, 'Trans-Pink', 'E4ADC8'),
(232, 'Sky Blue', '7DBFDD'),
(236, 'Trans-Light Purple', '96709F'),
(272, 'Dark Blue', '0A3463'),
(288, 'Dark Green', '184632'),
(294, 'Glow In Dark Trans', 'BDC6AD'),
(297, 'Pearl Gold', 'AA7F2E'),
(308, 'Dark Brown', '352100'),
(313, 'Maersk Blue', '3592C3'),
(320, 'Dark Red', '720E0F'),
(321, 'Dark Azure', '078BC9'),
(322, 'Medium Azure', '36AEBF'),
(323, 'Light Aqua', 'ADC3C0'),
(326, 'Olive Green', '9B9A5A'),
(334, 'Chrome Gold', 'BBA53D'),
(335, 'Sand Red', 'D67572'),
(351, 'Medium Dark Pink', 'F785B1'),
(366, 'Earth Orange', 'FA9C1C'),
(373, 'Sand Purple', '845E84'),
(378, 'Sand Green', 'A0BCAC'),
(379, 'Sand Blue', '6074A1'),
(383, 'Chrome Silver', 'E0E0E0'),
(450, 'Fabuland Brown', 'B67B50'),
(462, 'Medium Orange', 'FFA70B'),
(484, 'Dark Orange', 'A95500'),
(503, 'Very Light Gray', 'E6E3DA'),
(1000, 'Glow in Dark White', 'D9D9D9'),
(1001, 'Medium Violet', '9391E4'),
(1002, 'Glitter Trans-Neon Green', 'C0F500'),
(1003, 'Glitter Trans-Light Blue', '68BCC5'),
(1004, 'Trans-Flame Yellowish Orange', 'FCB76D'),
(1005, 'Trans-Fire Yellow', 'FBE890'),
(1006, 'Trans-Light Royal Blue', 'B4D4F7'),
(1007, 'Reddish Lilac', '8E5597'),
(1008, 'Vintage Blue', '039CBD'),
(1009, 'Vintage Green', '1E601E'),
(1010, 'Vintage Red', 'CA1F08'),
(1011, 'Vintage Yellow', 'F3C305'),
(1012, 'Fabuland Orange', 'EF9121'),
(1013, 'Modulex White', 'F4F4F4'),
(1014, 'Modulex Light Bluish Gray', 'AfB5C7'),
(1015, 'Modulex Light Gray', '9C9C9C'),
(1016, 'Modulex Charcoal Gray', '595D60'),
(1017, 'Modulex Tile Gray', '6B5A5A'),
(1018, 'Modulex Black', '4D4C52'),
(1019, 'Modulex Tile Brown', '330000'),
(1020, 'Modulex Terracotta', '5C5030'),
(1021, 'Modulex Brown', '907450'),
(1022, 'Modulex Buff', 'DEC69C'),
(1023, 'Modulex Red', 'B52C20'),
(1024, 'Modulex Pink Red', 'F45C40'),
(1025, 'Modulex Orange', 'F47B30'),
(1026, 'Modulex Light Orange', 'F7AD63'),
(1027, 'Modulex Light Yellow', 'FFE371'),
(1028, 'Modulex Ochre Yellow', 'FED557'),
(1029, 'Modulex Lemon', 'BDC618'),
(1030, 'Modulex Pastel Green', '7DB538'),
(1031, 'Modulex Olive Green', '7C9051'),
(1032, 'Modulex Aqua Green', '27867E'),
(1033, 'Modulex Teal Blue', '467083'),
(1034, 'Modulex Tile Blue', '0057A6'),
(1035, 'Modulex Medium Blue', '61AFFF'),
(1036, 'Modulex Pastel Blue', '68AECE'),
(1037, 'Modulex Violet', 'BD7D85'),
(1038, 'Modulex Pink', 'F785B1'),
(1039, 'Modulex Clear', 'FFFFFF'),
(1040, 'Modulex Foil Dark Gray', '595D60'),
(1041, 'Modulex Foil Light Gray', '9C9C9C'),
(1042, 'Modulex Foil Dark Green', '006400'),
(1043, 'Modulex Foil Light Green', '7DB538'),
(1044, 'Modulex Foil Dark Blue', '0057A6'),
(1045, 'Modulex Foil Light Blue', '68AECE'),
(1046, 'Modulex Foil Violet', '4B0082'),
(1047, 'Modulex Foil Red', '8B0000'),
(1048, 'Modulex Foil Yellow', 'FED557'),
(1049, 'Modulex Foil Orange', 'F7AD63'),
(1050, 'Coral', 'FF698F'),
(1051, 'Pastel Blue', '5AC4DA'),
(1052, 'Glitter Trans-Orange', 'F08F1C'),
(1053, 'Opal Trans-Light Blue', '68BCC5'),
(1054, 'Opal Trans-Dark Pink', 'CE1D9B'),
(1055, 'Opal Trans-Clear', 'FCFCFC'),
(1056, 'Opal Trans-Brown', '583927'),
(1057, 'Trans-Light Bright Green', 'C9E788'),
(1058, 'Trans-Light Green', '94E5AB'),
(1059, 'Opal Trans-Purple', '8320B7'),
(1060, 'Opal Trans-Bright Green', '84B68D'),
(1061, 'Opal Trans-Dark Blue', '0020A0'),
(1062, 'Vibrant Yellow', 'EBD800'),
(1063, 'Pearl Copper', 'B46A00'),
(1064, 'Fabuland Red', 'FF8014'),
(1065, 'Reddish Gold', 'AC8247'),
(1066, 'Curry', 'DD982E'),
(1067, 'Dark Nougat', 'AD6140'),
(1068, 'Bright Reddish Orange', 'EE5434'),
(1069, 'Pearl Red', 'D60026'),
(1070, 'Pearl Blue', '0059A3'),
(1071, 'Pearl Green', '008E3C'),
(1072, 'Pearl Brown', '57392C'),
(1073, 'Pearl Black', '0A1327'),
(1074, 'Duplo Blue', '009ECE'),
(1075, 'Duplo Medium Blue', '3E95B6'),
(1076, 'Duplo Lime', 'FFF230'),
(1077, 'Fabuland Lime', '78FC78'),
(1078, 'Duplo Medium Green', '468A5F'),
(1079, 'Duplo Light Green', '60BA76'),
(1080, 'Light Tan', 'F3C988'),
(1081, 'Rust Orange', '872B17'),
(1082, 'Clikits Pink', 'FE78B0'),
(1083, 'Two-tone Copper', '945148'),
(1084, 'Two-tone Gold', 'AB673A'),
(1085, 'Two-tone Silver', '737271'),
(1086, 'Pearl Lime', '6A7944'),
(1087, 'Duplo Pink', 'FF879C'),
(1088, 'Medium Brown', '755945'),
(1089, 'Warm Tan', 'CCA373'),
(1090, 'Duplo Turquoise', '3FB69E'),
(1091, 'Warm Yellowish Orange', 'FFCB78'),
(1092, 'Metallic Copper', '764D3B'),
(1093, 'Light Lilac', '9195CA'),
(1094, 'Trans-Medium Purple', '8D73B3'),
(1095, 'Trans-Black', '635F52'),
(1096, 'Glitter Trans-Bright Green', 'D9E4A7'),
(1097, 'Glitter Trans-Medium Purple', '8D73B3'),
(1098, 'Glitter Trans-Green', '84B68D'),
(1099, 'Glitter Trans-Pink', 'E4ADC8'),
(1100, 'Clikits Yellow', 'FFCF0B'),
(1101, 'Duplo Dark Purple', '5F27AA'),
(1102, 'Trans-Neon Red', 'FF0040'),
(1103, 'Pearl Titanium', '3E3C39'),
(1104, 'HO Aqua', 'B3D7D1'),
(1105, 'HO Azure', '1591cb'),
(1106, 'HO Blue-gray', '354e5a'),
(1107, 'HO Cyan', '5b98b3'),
(1108, 'HO Dark Aqua', 'a7dccf'),
(1109, 'HO Dark Blue', '0A3463'),
(1110, 'HO Dark Gray', '6D6E5C'),
(1111, 'HO Dark Green', '184632'),
(1112, 'HO Dark Lime', 'b2b955'),
(1113, 'HO Dark Red', '631314'),
(1114, 'HO Dark Sand Green', '627a62'),
(1115, 'HO Dark Turquoise', '10929d'),
(1116, 'HO Earth Orange', 'bb771b'),
(1117, 'HO Gold', 'b4a774'),
(1118, 'HO Light Aqua', 'a3d1c0'),
(1119, 'HO Light Brown', '965336'),
(1120, 'HO Light Gold', 'cdc298'),
(1121, 'HO Light Tan', 'f9f1c7'),
(1122, 'HO Light Yellow', 'f5fab7'),
(1123, 'HO Medium Blue', '7396c8'),
(1124, 'HO Medium Red', 'c01111'),
(1125, 'HO Metallic Blue', '0d4763'),
(1126, 'HO Metallic Dark Gray', '5e5e5e'),
(1127, 'HO Metallic Green', '879867'),
(1128, 'HO Metallic Sand Blue', '5f7d8c'),
(1129, 'HO Olive Green', '9B9A5A'),
(1130, 'HO Rose', 'd06262'),
(1131, 'HO Sand Blue', '6e8aa6'),
(1132, 'HO Sand Green', 'A0BCAC'),
(1133, 'HO Tan', 'E4CD9E'),
(1134, 'HO Titanium', '616161'),
(1135, 'Metal', 'A5ADB4'),
(1136, 'Reddish Orange', 'CA4C0B'),
(1137, 'Sienna Brown', '915C3C'),
(1138, 'Umber Brown', '5E3F33'),
(1139, 'Opal Trans-Yellow', 'F5CD2F'),
(1140, 'Neon Orange', 'EC4612'),
(1141, 'Neon Green', 'D2FC43'),
(1142, 'Dark Olive Green', '5d5c36'),
(1143, 'Glitter Milky White', 'FFFFFF'),
(1144, 'Chrome Red', 'CE3021'),
(1145, 'Ochre Yellow', 'DD9E47'),
(9999, '[No Color/Any Color]', '05131D');

-- --------------------------------------------------------

--
-- Structure de la table `factory_orders`
--

CREATE TABLE `factory_orders` (
  `quote_id` varchar(100) NOT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'PENDING',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `content_json` longtext NOT NULL COMMENT 'Snapshot complet (adresse + lignes) au format JSON pour immutabilité totale',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `mosaic`
--

CREATE TABLE `mosaic` (
  `id` int(11) NOT NULL,
  `uploads_id` int(11) NOT NULL,
  `version_name` varchar(50) DEFAULT NULL,
  `filter_used` varchar(50) DEFAULT NULL,
  `size_option` varchar(20) DEFAULT NULL,
  `color_count` int(11) DEFAULT 0,
  `estimated_price` decimal(8,2) DEFAULT 0.00,
  `preview_path` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `blueprint_data` longtext DEFAULT NULL COMMENT 'JSON contenant le plan/matrice des briques',
  `is_locked` tinyint(1) DEFAULT 0 COMMENT 'Si 1, la mosaïque est liée à une commande et ne doit plus changer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mosaic_id` int(11) NOT NULL,
  `shipping_address_id` int(11) DEFAULT NULL,
  `order_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','paid','shipped','delivered','cancelled') DEFAULT 'pending',
  `total_amount` decimal(8,2) DEFAULT NULL,
  `payment_method` enum('paypal','card') DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `brick_ref` varchar(50) NOT NULL,
  `color_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price_frozen` decimal(10,2) NOT NULL COMMENT 'Prix de la brique au moment de l achat'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déclencheurs `order_items`
--
DELIMITER $$
CREATE TRIGGER `after_order_items_insert_update_stock` AFTER INSERT ON `order_items` FOR EACH ROW BEGIN
    -- On déduit la quantité commandée du stock
    UPDATE stock
    SET quantity = quantity - NEW.quantity
    WHERE brick_ref = NEW.brick_ref AND color_id = NEW.color_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_order_items_insert` BEFORE INSERT ON `order_items` FOR EACH ROW BEGIN
    -- On récupère le prix actuel du stock
    DECLARE current_price DECIMAL(10,2);
    
    SELECT price_per_unit INTO current_price
    FROM stock
    WHERE brick_ref = NEW.brick_ref AND color_id = NEW.color_id;

    -- On force l'enregistrement de ce prix dans la commande
    -- Même si le prix du stock change demain, celui-ci restera fixe
    SET NEW.unit_price_frozen = IFNULL(current_price, 0.00);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `prevent_negative_stock` BEFORE INSERT ON `order_items` FOR EACH ROW BEGIN
    DECLARE current_stock INT;

    SELECT quantity INTO current_stock
    FROM stock
    WHERE brick_ref = NEW.brick_ref AND color_id = NEW.color_id;

    IF current_stock < NEW.quantity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Erreur : Stock insuffisant pour cette pièce.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `brick_ref` varchar(50) NOT NULL,
  `color_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 0,
  `alert_threshold` int(11) DEFAULT 10 COMMENT 'Seuil alerte stock bas',
  `price_per_unit` decimal(10,2) DEFAULT 0.00 COMMENT 'Prix unitaire actuel de la brique'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `translation`
--

CREATE TABLE `translation` (
  `id` int(11) NOT NULL,
  `lang_code` char(2) NOT NULL,
  `key_name` varchar(100) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `uploads`
--

CREATE TABLE `uploads` (
  `id_upload` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `image_data` longblob NOT NULL,
  `image_type` varchar(50) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` char(15) NOT NULL,
  `birth_year` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `two_factor_code` varchar(6) DEFAULT NULL,
  `two_factor_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reset_token` varchar(100) DEFAULT NULL,
  `reset_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user_log`
--

CREATE TABLE `user_log` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `level` varchar(20) NOT NULL DEFAULT 'INFO',
  `message` text NOT NULL,
  `action` varchar(100) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_admin_orders`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `v_admin_orders` (
`order_id` int(11)
,`order_number` varchar(50)
,`username` varchar(50)
,`email` varchar(100)
,`status` enum('pending','paid','shipped','delivered','cancelled')
,`total_amount` decimal(8,2)
,`created_at` datetime
,`total_items` bigint(21)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_stock_alerts`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `v_stock_alerts` (
`brick_ref` varchar(50)
,`color_id` int(11)
,`color_name` varchar(100)
,`hex_code` char(6)
,`quantity` int(11)
,`alert_threshold` int(11)
,`price_per_unit` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Structure de la vue `v_admin_orders`
--
DROP TABLE IF EXISTS `v_admin_orders`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_admin_orders`  AS SELECT `o`.`id` AS `order_id`, `o`.`order_number` AS `order_number`, `u`.`username` AS `username`, `u`.`email` AS `email`, `o`.`status` AS `status`, `o`.`total_amount` AS `total_amount`, `o`.`created_at` AS `created_at`, (select count(0) from `order_items` `oi` where `oi`.`order_id` = `o`.`id`) AS `total_items` FROM (`orders` `o` join `users` `u` on(`o`.`user_id` = `u`.`id_user`)) ORDER BY `o`.`created_at` DESC ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_stock_alerts`
--
DROP TABLE IF EXISTS `v_stock_alerts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_stock_alerts`  AS SELECT `s`.`brick_ref` AS `brick_ref`, `s`.`color_id` AS `color_id`, `c`.`name` AS `color_name`, `c`.`hex_code` AS `hex_code`, `s`.`quantity` AS `quantity`, `s`.`alert_threshold` AS `alert_threshold`, `s`.`price_per_unit` AS `price_per_unit` FROM (`stock` `s` join `colors` `c` on(`s`.`color_id` = `c`.`id`)) WHERE `s`.`quantity` <= `s`.`alert_threshold` ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `upload_id` (`mosaic_id`);

--
-- Index pour la table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factory_orders`
--
ALTER TABLE `factory_orders`
  ADD PRIMARY KEY (`quote_id`);

--
-- Index pour la table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Index pour la table `mosaic`
--
ALTER TABLE `mosaic`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploads_id` (`uploads_id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `mosaic_id` (`mosaic_id`),
  ADD KEY `shipping_address_id` (`shipping_address_id`);

--
-- Index pour la table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`brick_ref`,`color_id`),
  ADD KEY `color_id` (`color_id`);

--
-- Index pour la table `translation`
--
ALTER TABLE `translation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lang_code` (`lang_code`,`key_name`);

--
-- Index pour la table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id_upload`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `phonenumber` (`phone_number`);

--
-- Index pour la table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `mosaic`
--
ALTER TABLE `mosaic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `translation`
--
ALTER TABLE `translation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id_upload` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON DELETE CASCADE;

--
-- Contraintes pour la table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_ibfk_mosaic` FOREIGN KEY (`mosaic_id`) REFERENCES `mosaic` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `mosaic`
--
ALTER TABLE `mosaic`
  ADD CONSTRAINT `mosaic_ibfk_1` FOREIGN KEY (`uploads_id`) REFERENCES `uploads` (`id_upload`) ON DELETE CASCADE;

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`mosaic_id`) REFERENCES `mosaic` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`shipping_address_id`) REFERENCES `address` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `uploads`
--
ALTER TABLE `uploads`
  ADD CONSTRAINT `uploads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `user_log`
--
ALTER TABLE `user_log`
  ADD CONSTRAINT `user_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_user`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
