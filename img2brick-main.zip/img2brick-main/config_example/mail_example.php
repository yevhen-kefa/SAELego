<?php
return [
    'smtp_host' => 'partage.univ-eiffel.fr',
    'smtp_user' => 'issam.ben-hamouda@edu.univ-eiffel.fr',
    'smtp_pass' => '',
    'smtp_port' => 587
];